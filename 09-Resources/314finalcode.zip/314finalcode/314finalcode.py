# ================================================================== #
#  node_G_combined.py  –  Node G                                     #
#  Hardware : ESP32-S3 WROOM-1  |  Runtime : MicroPython             #
#                                                                     #
#  UART mesh                                                          #
#    · Receives speed commands (fast / slow / stop) from J           #
#    · Receives direction-toggle command  (ButtonOn)  from A         #
#    · Relays any message not addressed to G unchanged               #
#                                                                     #
#  Motor                                                              #
#    · Direction set via SPI motor-driver command bytes              #
#    · Speed  set via PWM duty cycle on Pin 41                       #
#      fast  →  75 %   slow  →  25 %   stop  →  0 %                 #
# ================================================================== #

from machine import UART, Pin, SPI, PWM
import uasyncio as asyncio

# ------------------------------------------------------------------ #
#  Network constants                                                  #
# ------------------------------------------------------------------ #
TEAM        = [b'A', b'J', b'D', b'E', b'G', b'k', b'Z']
MY_ID       = b'G'
BROADCAST   = b'M'
MAX_MSG_LEN = 64

# ------------------------------------------------------------------ #
#  UART  (unchanged from original)                                   #
# ------------------------------------------------------------------ #
uart = UART(2, 9600, tx=43, rx=44)
uart.init(9600, bits=8, parity=None, stop=1)

# ------------------------------------------------------------------ #
#  SPI motor driver                                                   #
# ------------------------------------------------------------------ #
spi = SPI(
    2,
    baudrate=1_000_000,
    polarity=0,
    phase=1,
    sck=Pin(21),
    mosi=Pin(47),
    miso=Pin(48),
)

cs      = Pin(45, Pin.OUT)
dis     = Pin(40, Pin.OUT)      # LOW  = chip enabled
# NOTE: Pin 41 is now PWM so the driver can receive variable duty
pwm_out = PWM(Pin(41), freq=1_000)
dir_pin = Pin(39, Pin.OUT)

# SPI command bytes (unchanged from original motor code)
_FWD = bytes([0b11101111])
_REV = bytes([0b11101101])

# Pre-computed PWM duty values  (duty() uses a 0–1023 scale on ESP32)
_DUTY_FAST = int(1023 * 0.75)   # 75 %  →  767
_DUTY_SLOW = int(1023 * 0.25)   # 25 %  →  255
_DUTY_STOP = 0                   #  0 %  →  motor off

# ------------------------------------------------------------------ #
#  Motor state                                                        #
# ------------------------------------------------------------------ #
_motor_dir = 'fwd'   # tracks current direction: 'fwd' | 'rev'

def _apply_direction():
    """Send one SPI frame and set dir_pin to match _motor_dir."""
    cs.value(0)
    spi.write(_FWD if _motor_dir == 'fwd' else _REV)
    cs.value(1)
    dir_pin.value(1 if _motor_dir == 'fwd' else 0)

def motor_set_speed(duty: int):
    """
    Set PWM duty cycle.
    Also re-sends the SPI direction frame so the driver is always
    in a known, consistent state when speed changes.
    """
    dis.value(0)            # keep chip enabled
    _apply_direction()      # re-affirm direction via SPI
    pwm_out.duty(duty)
    print('Motor speed duty:', duty, '/ 1023')

def motor_stop():
    """Zero the PWM output.  Direction state is preserved for next start."""
    pwm_out.duty(_DUTY_STOP)
    print('Motor STOPPED')

def motor_toggle_direction():
    """Flip _motor_dir and push the new value to the SPI driver."""
    global _motor_dir
    _motor_dir = 'rev' if _motor_dir == 'fwd' else 'fwd'
    _apply_direction()
    print('Motor direction →', _motor_dir.upper())

# ------------------------------------------------------------------ #
#  LEDs                                                               #
# ------------------------------------------------------------------ #
led_fast = Pin(16, Pin.OUT)   # rapid flashes on 'fast'
led_slow = Pin(17, Pin.OUT)   # slow flashes  on 'slow'
led_stop = Pin(18, Pin.OUT)   # single long blink on 'stop'

async def flash_led(pin, times=5, on_ms=300, off_ms=300):
    """Non-blocking LED flash pattern — runs as a background task."""
    for _ in range(times):
        pin.on();  await asyncio.sleep_ms(on_ms)
        pin.off(); await asyncio.sleep_ms(off_ms)

# ------------------------------------------------------------------ #
#  UART transmit helpers                                              #
# ------------------------------------------------------------------ #
def _tx(receiver: bytes, payload: bytes):
    msg = b'AZ' + MY_ID + receiver + payload + b'YB'
    uart.write(msg)
    return msg

def send_motor_on():
    """Sent once on boot to announce the motor node is active."""
    msg = _tx(b'A', b'MotorOn')
    print('TX → A : MotorOn |', msg)

def send_motor_status(status: bytes):
    """Report current speed state back to D."""
    msg = _tx(b'D', b'motor' + status)
    print('TX → D : motor' + status.decode(), '|', msg)

def relay_message(raw: bytes):
    """Re-transmit a frame that was not addressed to us."""
    uart.write(raw)
    print('Relayed:', raw)

# ------------------------------------------------------------------ #
#  Incoming message handler                                           #
#                                                                     #
#  Full frame layout:                                                 #
#    [0:2]  = b'AZ'   start marker                                   #
#    [2:3]  = sender id                                               #
#    [3:4]  = receiver id                                             #
#    [4:-2] = payload                                                 #
#    [-2:]  = b'YB'   end marker                                      #
# ------------------------------------------------------------------ #
def handle_message(message: bytes):
    print('RX raw:', message)

    if len(message) < 7:       # minimum: AZ + s + r + 1 payload byte + YB
        return

    sender   = message[2:3]
    receiver = message[3:4]
    payload  = message[4:-2]

    print('  sender:', sender,
          '| receiver:', receiver,
          '| payload:', payload)

    # Not for us — relay and exit
    if receiver != MY_ID:
        print('  Not for us — relaying')
        relay_message(message)
        return

    # -------------------------------------------------------------- #
    #  Commands from J  (speed control)                              #
    # -------------------------------------------------------------- #
    if sender == b'J':

        if payload == b'fast':
            print('  J → FAST (75 %)')
            motor_set_speed(_DUTY_FAST)
            asyncio.create_task(
                flash_led(led_fast, times=5, on_ms=100, off_ms=100)
            )
            send_motor_status(b'fast')

        elif payload == b'slow':
            print('  J → SLOW (25 %)')
            motor_set_speed(_DUTY_SLOW)
            asyncio.create_task(
                flash_led(led_slow, times=3, on_ms=500, off_ms=500)
            )
            send_motor_status(b'slow')

        elif payload == b'stop':
            print('  J → STOP')
            motor_stop()
            asyncio.create_task(
                flash_led(led_stop, times=1, on_ms=1000, off_ms=0)
            )
            send_motor_status(b'stop')

    # -------------------------------------------------------------- #
    #  Commands from A  (direction toggle)                           #
    # -------------------------------------------------------------- #
    elif sender == b'A':

        if payload == b'button on':
            print('  A → Button On  →  toggling direction')
            motor_toggle_direction()

# ------------------------------------------------------------------ #
#  UART receive coroutine                                             #
# ------------------------------------------------------------------ #
async def process_rx():
    stream            = b''
    message           = b''
    receiving_message = False

    while True:
        c = uart.read(1)
        if c is not None:
            stream += c

            # ---- detect start marker b'AZ' ---- #
            try:
                if stream[-2:] == b'AZ':
                    message           = stream[-2:-1]   # seed with b'A'
                    receiving_message = True
            except IndexError:
                pass

            # ---- detect end marker b'YB' ---- #
            try:
                if stream[-2:] == b'YB':
                    message          += stream[-1:]     # append b'B'
                    stream            = b''
                    receiving_message = False
                    handle_message(message)
                    message           = b''
            except IndexError:
                pass

            # ---- accumulate frame bytes ---- #
            if receiving_message:
                message += c

                if len(message) == 3:
                    if message[2:3] not in TEAM:
                        print('  Warning: sender not in team')
                    elif message[2:3] == MY_ID:
                        print('  Warning: sender is self')

                if len(message) == 4:
                    if message[3:4] == BROADCAST:
                        print('  Broadcast message')
                    elif message[3:4] not in TEAM:
                        print('  Warning: receiver not in team')

                if len(message) > MAX_MSG_LEN:
                    receiving_message = False
                    message           = b''
                    print('  Message exceeded MAX_MSG_LEN — aborted')

        await asyncio.sleep_ms(10)

# ------------------------------------------------------------------ #
#  Async main  (keeps the event loop alive)                          #
# ------------------------------------------------------------------ #
async def main():
    while True:
        await asyncio.sleep(1)

# ------------------------------------------------------------------ #
#  Boot sequence                                                      #
# ------------------------------------------------------------------ #
cs.value(1)                     # deselect SPI device initially
dis.value(0)                    # enable motor driver chip
_apply_direction()              # push initial FWD command via SPI
pwm_out.duty(_DUTY_STOP)        # motor starts stopped

send_motor_on()                 # announce to network once on boot

asyncio.create_task(process_rx())   # start UART listener

try:
    asyncio.run(main())
finally:
    asyncio.new_event_loop()
